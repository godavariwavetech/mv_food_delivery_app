import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { AuthContext } from '../context/AuthContext';
import ApiService from '../services/apiservice';

// We'll use a more modern shade of green for your theme
const THEME_COLOR = '#28a745'; // A pleasant, modern green
const DISABLED_COLOR = '#90D5A1'; // A lighter, disabled version of the theme color

const LoginScreen = ({ navigation }) => {
  // --- Original State Management (Unchanged) ---
  const { login } = useContext(AuthContext);
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ mobileNumber: '', password: '' });
  const [touched, setTouched] = useState({ mobileNumber: false, password: false });
  const [loading, setLoading] = useState(false);
  
  // State for password visibility toggle
  const [showPassword, setShowPassword] = useState(false);

  // --- Original Validation Logic (Unchanged) ---
  const validatePhoneNumber = (number) => {
    const indianPhoneRegex = /^[6-9]\d{9}$/;
    if (!number) return 'Phone number is required';
    if (number.length !== 10) return 'Phone number must be 10 digits';
    if (!indianPhoneRegex.test(number)) return 'Invalid number. Must start with 6, 7, 8, or 9';
    return '';
  };

  const validatePassword = (pass) => {
    if (!pass) return 'Password is required';
    if (pass.length < 6) return 'Password must be at least 6 characters';
    return '';
  };

  // --- Original Handlers (Unchanged) ---
  const handleMobileChange = (text) => {
    setMobileNumber(text);
    if (touched.mobileNumber) {
      setErrors((prevErrors) => ({ ...prevErrors, mobileNumber: validatePhoneNumber(text) }));
    }
  };

  const handlePasswordChange = (text) => {
    setPassword(text);
    if (touched.password) {
      setErrors((prevErrors) => ({ ...prevErrors, password: validatePassword(text) }));
    }
  };

  const handleBlur = (field) => {
    setTouched((prevTouched) => ({ ...prevTouched, [field]: true }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: field === 'mobileNumber' ? validatePhoneNumber(mobileNumber) : validatePassword(password),
    }));
  };

  const handleLogin = async () => {
    if (isButtonEnabled) {
      setLoading(true);
      try {
        const response = await ApiService.login(mobileNumber, password);
        if (response.status === 200 && response.data.length > 0) {
          login(response.data[0]);
          navigation.replace('MainApp');
        } else {
          Alert.alert('Error', 'Invalid credentials');
        }
      } catch (error) {
        console.error('Login Error:', error);
        Alert.alert('Login Failed', error.message || 'Something went wrong');
      } finally {
        setLoading(false);
      }
    }
  };

  // --- Original Button Enable Logic (Unchanged) ---
  const isButtonEnabled =
    mobileNumber.length === 10 &&
    password.length >= 6 &&
    !errors.mobileNumber &&
    !errors.password;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Welcome!</Text>
          <Text style={styles.subtitle}>Please log in to continue.</Text>
        </View>

        {/* --- Mobile Number Input --- */}
        <View style={styles.inputContainer}>
          <Feather name="phone" size={20} color="#6C757D" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            placeholderTextColor="#6C757D"
            keyboardType="phone-pad"
            maxLength={10}
            value={mobileNumber}
            onChangeText={handleMobileChange}
            onBlur={() => handleBlur('mobileNumber')}
          />
        </View>
        {touched.mobileNumber && errors.mobileNumber ? <Text style={styles.errorText}>{errors.mobileNumber}</Text> : null}

        {/* --- Password Input --- */}
        <View style={styles.inputContainer}>
          <Feather name="lock" size={20} color="#6C757D" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#6C757D"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={handlePasswordChange}
            onBlur={() => handleBlur('password')}
          />
          <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
            <Feather name={showPassword ? 'eye-off' : 'eye'} size={20} color="#6C757D" />
          </TouchableOpacity>
        </View>
        {touched.password && errors.password ? <Text style={styles.errorText}>{errors.password}</Text> : null}
        
        {/* --- Login Button --- */}
        <TouchableOpacity
          style={[styles.loginButton, !isButtonEnabled && styles.disabledButton]}
          onPress={handleLogin}
          disabled={!isButtonEnabled || loading}>
          {loading ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.loginText}>Log In</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

// --- Modern Stylesheet with Green Theme ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1D2A32',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6C757D',
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  icon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 48,
    fontSize: 16,
    color: '#1D2A32',
  },
  errorText: {
    color: '#E53E3E',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
  },
  loginButton: {
    width: '100%',
    backgroundColor: THEME_COLOR,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 30, // Increased margin top for better spacing
  },
  disabledButton: {
    backgroundColor: DISABLED_COLOR,
  },
  loginText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default LoginScreen;